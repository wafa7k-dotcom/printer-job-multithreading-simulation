import java.util.LinkedList;

// Buffer class to store jobs with synchronization
class Buffer {
    private final LinkedList<String> list; // LinkedList to store jobs
    private final int maxSize;

    public Buffer(int maxSize) {
        this.list = new LinkedList<>();
        this.maxSize = maxSize;
    }
     
    public int getMaxSize() { 
       return maxSize; 
    }
    

    // Method to add a job to the buffer
    public synchronized void addJob(String job) throws InterruptedException {
        while (list.size() == maxSize) { // Wait if buffer is full
            System.out.println("Buffer full. Writer waiting...");
            wait(); // Release the lock and wait for space
        }
        list.addLast(job); // Add job to the end of the list
        System.out.println("Write: " + job + " | Buffer Size: " + list.size());
        notifyAll(); // Notify other threads that the buffer has changed
    }

    // Method to remove a job from the buffer
    public synchronized String removeJob() throws InterruptedException {
        while (list.isEmpty()) { // Wait if buffer is empty
            System.out.println("Buffer empty. Reader waiting...");
            wait(); // Release the lock and wait for a job
        }
        String job = list.removeFirst(); // Remove the job from the beginning of the list
        System.out.println("Read: " + job + " | Buffer size: " + list.size());
        notifyAll(); // Notify other threads that the buffer has changed
        return job;
    }

    // Method to check if the buffer is empty
    public synchronized boolean isEmpty() {
        return list.isEmpty();
    }
}

