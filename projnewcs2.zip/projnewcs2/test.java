public class test {

    public static void main(String[] args) {
       Buffer buffer = new Buffer(20);  // Create a buffer with a size of 20
        // Create and start writer threads
        Thread writeFirstTh = new Thread(new WriteJobs(buffer));
        Thread writeSecondTh = new Thread(new WriteJobs(buffer));
        writeFirstTh.start();
        writeSecondTh.start();

        // Create and start reader threads
        Thread readFirstTh = new Thread(new ReadJobs(buffer));
        Thread readSecondTh = new Thread(new ReadJobs(buffer));
        readFirstTh.start();
        readSecondTh.start();

        // Wait for all threads to finish
        try {
            writeFirstTh.join();
            writeSecondTh.join();
            readFirstTh.join();
            readSecondTh.join();
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted.");
            Thread.currentThread().interrupt();
        }

        // Ensure the buffer is empty before exiting
        if (buffer.isEmpty()) {
            System.out.println("Buffer is empty. Exiting program.");
        } else {
            System.out.println("Buffer is not empty. Exiting program.");
        }

        System.out.println("All threads finished. Main thread exiting.");
    }
}
