// Reader thread to remove jobs
class ReadJobs implements Runnable {
    private final Buffer buffer;
    private final int numJobs; // Total number of jobs to remove

    public ReadJobs(Buffer buffer) {
        this.buffer = buffer;
        this.numJobs = buffer.getMaxSize(); // We used the buffer size as the number of jobs
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= numJobs; i++) { 
                buffer.removeJob();
                Thread.sleep(1000); // 1 second delay
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("ReadJobs interrupted.");
        }
    }
}


