// Writer thread to add jobs
class WriteJobs implements Runnable {
   private final Buffer buffer;
   private final int numJobs; // Total number of jobs to add

   public WriteJobs(Buffer buffer) { 
   this.buffer = buffer;
   this.numJobs = buffer.getMaxSize(); // We used the buffer size as the number of jobs
                                    
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= numJobs; i++) { 
                String job = "Job " + i;
                buffer.addJob(job);
                Thread.sleep(500); // 1/2 second delay
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("WriteJobs interrupted.");
        }
    }
}
